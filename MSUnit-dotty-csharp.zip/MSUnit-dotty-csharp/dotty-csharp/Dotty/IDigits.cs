﻿namespace Dotty
{
    public interface IDigits
    {
        string[] StringNumber();
    }
}
