﻿namespace Dotty
{
    public enum DigitType
    {
        One,
        Two,
        Three,
        Five,
        Seven
    }
}
