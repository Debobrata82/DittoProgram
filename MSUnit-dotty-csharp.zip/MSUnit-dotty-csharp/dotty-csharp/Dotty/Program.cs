﻿using System;
using System.IO;
using System.Linq;

namespace Dotty
{
    public class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter the file name of name input.txt or input8.txt .. etc :");
            var fName = Console.ReadLine();

            string path = @"D:\Work\MSUnit-dotty-csharp\dotty-csharp\Dotty\" + fName;
            string[] lines = null;
            try
            {
                lines = File.ReadAllLines(path);
            }
            catch (IOException)
            {
                Console.WriteLine("File doesnt exist in : " + path);
                return;
            }

            var result = IsDigitStringsGenerationSuccessful(lines);
            if (!result)
                Console.WriteLine("The input text file content and and digit string does not match");

            Console.ReadLine();

        }

        public static bool IsDigitStringsGenerationSuccessful(string[] lines)
        {
            if (Enumerable.SequenceEqual(Digits.Strings1, lines))
            {
                Console.WriteLine("The number is 1");
                return true;
            }
            else if (Enumerable.SequenceEqual(Digits.Strings3, lines))
            {
                Console.WriteLine("The number is 3");
                return true;
            }
            else if (Enumerable.SequenceEqual(Digits.Strings8, lines))
            {
                Console.WriteLine("The number is 8");
                return true;
            }

            //Factory Implementation
            //var res = FactoryDigitsProvider.FactoryStringGenerate(DigitType.Five);
            //var result = Enumerable.SequenceEqual(res.StringNumber(), lines);

            return false;
        }
    }
}
