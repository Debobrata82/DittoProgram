﻿namespace Dotty
{
    public class FactoryDigitsProvider
    {

        public static IDigits FactoryStringGenerate(DigitType digitType)
        {
            switch (digitType)
            {
                case DigitType.Five:
                    return new String5Digits();

                case DigitType.Seven:
                    return new String7Digits();

                default:
                    return null;
            }
        }
    }
}
