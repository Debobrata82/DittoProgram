﻿namespace Dotty
{
    public class String5Digits : IDigits
    {

        public string[] StringNumber()
        {
                return new string[]
                {
                    " ... ",
                    ".   .",
                    "    .",
                    " ... ",
                    "    .",
                    ".   .",
                    " ... "
                };
        }
    }
}
