﻿namespace Dotty
{
    public class String7Digits : IDigits
    {
        public string[] StringNumber()
        {
            return new string[]
            {
                    " ... ",
                    ".   .",
                    "    .",
                    " ... ",
                    "    .",
                    ".   .",
                    " ... "
            };
        }
    }
}
