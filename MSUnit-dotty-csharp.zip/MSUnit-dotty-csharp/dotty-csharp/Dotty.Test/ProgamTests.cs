﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Dotty.Test
{
    [TestClass]
    public class ProgamTests
    {
        [TestMethod]
        public void TestTrueIsTrue()
        {
            Assert.AreEqual(true, true);
        }

        [TestMethod]
        public void TestString3Generation()
        {
            // Arrange
            string[] testData =
            {
                    " ... ",
                    ".   .",
                    "    .",
                    " ... ",
                    "    .",
                    ".   .",
                    " ... "
            };

            // Act
            bool result = Program.IsDigitStringsGenerationSuccessful(testData);


            // Assert
            Assert.IsTrue(result);
        }
    }
}
