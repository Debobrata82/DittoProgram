
## Introduction

Dotty is a simple console application, which loads information from a file and outputs its result to the console.

ALL THE CODE IS YOURS TO MODIFY, DELETE OR UPDATE.

## Task

The aim of this project is to take the input from a file and output the appropriate integer to the console.  
The input takes the form of a simple array of periods and spaces, like a piece of ASCII art, that form the pattern of an integer.  
This input pattern needs to be translated in some way and the correct output printed to the console.

An example of an input file is included in the project: input.txt; this input should output the digit "3" to the console.

## NOTES

1. You can assume that any input file will only contain the equivalent of a single digit and they will always be of the same size. 
	(5 characters wide and 7 rows of data)
2. You can assume input will always be from a simple txt file.
3. You must be able to handle all digits from 0 to 9.

